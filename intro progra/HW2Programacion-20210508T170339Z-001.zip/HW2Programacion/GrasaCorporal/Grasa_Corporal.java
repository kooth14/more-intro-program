package GrasaCorporal;

import java.util.Scanner;

public class Grasa_Corporal {

  public static void main(String[] args) {
	double peso_c,grasa_c,porcentaje_c,medida_de_mu�eca,medida_de_cadera,medida_de_cintura, m_antebrazo,A1,A2,A3,A4,A5,B ;
	char sexo;
	String seguir = "si";
    Scanner leer=new Scanner(System.in);
    
    while (seguir.equals("si")) {
    	
        System.out.println("Ingrese si es masculino o femenino (F o M): ");
        sexo= leer.nextLine().charAt(0);
        while (Character.toLowerCase(sexo)!= 'f' && Character.toLowerCase(sexo)!= 'm') {
          System.out.println("ERROR, su sexo debe ser F o M, ingrese otra vez su sexo ");
          sexo = leer.nextLine().charAt(0);
        }
        
        System.out.println("ingrese su peso corporal en lb: ");
        peso_c=Double.parseDouble(leer.nextLine());
        while (peso_c < 0) {
          System.out.println("ERROR, el peso debe ser positivo, favor volver a ingresar su peso corporal.");
          peso_c = Double.parseDouble(leer.nextLine());
        }

        System.out.println("ingrese la medida de su  mu�eca en cm: ");
        medida_de_mu�eca = Double.parseDouble(leer.nextLine());
        while (medida_de_mu�eca < 0) {
          System.out.println("ERROR, el peso debe ser positivo, favor volver a ingresar la medida de su mu�eca.");
          medida_de_mu�eca = Double.parseDouble(leer.nextLine());
        }
      
        System.out.println("ingrese la medida de su cadera en cm: ");
        medida_de_cadera = Double.parseDouble(leer.nextLine());
        while (medida_de_cadera < 0) {
          System.out.println("ERROR, la medida debe ser positivo, favor volver a ingresar la medida de cadera.");
          medida_de_cadera = Double.parseDouble(leer.nextLine());
        }
        
        System.out.println("ingrese la medida de su cintura en cm: ");
        medida_de_cintura = Double.parseDouble(leer.nextLine());
        while (medida_de_cintura < 0) {
	  	    System.out.println("ERROR, la medida debe ser positivo, favor volver a ingresar la medida de su cintura.");
	  	    medida_de_cintura = Double.parseDouble(leer.nextLine());
        }
        while (medida_de_cintura > medida_de_cadera) {
          System.out.println("ERROR, la medida de su cintura es mayor que su cadera, favor vuelva a ingresar la medida de su cintura");
          medida_de_cintura = Double.parseDouble(leer.nextLine());
        }
          
        System.out.println("ingrese la medida de su antebrazo en cm: ");
        m_antebrazo = Double.parseDouble(leer.nextLine());
        
        if(Character.toLowerCase(sexo) == 'f') {				
          A1=(peso_c * 0.732) + 8.987;
          A2=medida_de_mu�eca/3.140;
          A3=medida_de_cintura*0.157;
          A4=medida_de_cadera*0.249;
          A5=m_antebrazo*0.434;
          B= A1 + A2 - A3 - A4 + A5;
          grasa_c=peso_c-B;
          porcentaje_c = grasa_c*100/peso_c;
          System.out.println("su grasa_c es: " + grasa_c);
          System.out.println("B es: " + B);
          System.out.println("el porcentaje de su grasa_c es: " + grasa_c);
        }
        else {
          A1=(peso_c*1.082)+94.42;
          A2=medida_de_cintura*4.15;
          B=A1-A2;
          grasa_c=peso_c-B;
          porcentaje_c=grasa_c *100/peso_c;
          
          System.out.println("la medida de su cintura es: " + medida_de_cintura + " cm ");
          System.out.println("su grasa corporal es: " + grasa_c + " lb ");
          System.out.println("el porcentaje de su grasa corporal es: " + porcentaje_c + " lb ");
        }
          
        System.out.println("otra?:");
        seguir=leer.nextLine();
    }    
    leer.close();
  }		
}
