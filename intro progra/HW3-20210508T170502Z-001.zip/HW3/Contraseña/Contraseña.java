package Contrase�a;

import java.util.Scanner;

public class Contrase�a {
	
  public static void main(String[] args) {
  	String contra, contra2;
  	Scanner leer=new Scanner(System.in);
    
  	String seguir = "si";
   
    while (seguir.equals("si")) {
    	
    while (true) {
      System.out.println("Ingrese su contrase�a:");
      contra = leer.nextLine();
      
      if (contra.length() < 6) {
        System.out.println("ERROR, debe ser mas de 6 caracteres. Otra vez.");
        continue;
      }

      if (contra.length() > 10) {
        System.out.println("ERROR, debe ser menos de 10 caracteres. Otra vez.");
        continue;
      }

      boolean tieneLetra = false;
      boolean tieneNumero = false;
      char ch;
      for(int i=0;i < contra.length();i++) {
        ch = contra.charAt(i);
        if( Character.isDigit(ch)) {
            tieneNumero = true;
        }
        else if (Character.isLetter(ch)) {
            tieneLetra = true;
        }
      }
      if (!tieneNumero || !tieneLetra) {
        System.out.println("ERROR, debe tener al menos un numero y una letra. Ingrese otra ves su contre�a.");
        continue;
      }
      break;
    }

    while (true) {
      System.out.println("Ahora, confirme su contrase�a:");
      contra2 = leer.nextLine();
      if (!contra.equals(contra2)) {
        System.out.println("ERROR, la segunda no coincide con la primera. Ingrese otra ves su contre�a.");
        continue;
      }
      break;
    }

    System.out.println("Bien hecho!");
    System.out.println("otra?:");
    seguir=leer.nextLine();
    System.out.println("Bien hecho!");
}    
    leer.close();
  }
}

